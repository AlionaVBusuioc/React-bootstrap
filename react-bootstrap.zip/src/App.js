import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Button} from 'react-bootstrap';
import Header from './Components/Header';

function App() {
  return (
    <div>
    <Header/>
  </div>
  );
}

export default App;
