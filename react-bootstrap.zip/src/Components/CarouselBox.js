import React, { Component } from 'react';
import Carousel from 'react-bootstrap/Carousel';
import forestImg from '../assets/forest.jpg';
import dforestImg from '../assets/dforest.jpg';
import sunforestImg from '../assets/sunforest.jpg';
import CarouselCaption from 'react-bootstrap/CarouselCaption';
import './CarouselBox.css';

export default class CarouselBox extends Component {
    render() {
        return (
          <Carousel>
          <Carousel.Item>
              <img
              className="d-block w-100 carousel"
              src={forestImg}
              alt="Forest"
              />
            <Carousel.Caption>
             <h3>Forest image</h3>
             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, maiores.</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
              <img 
              className="d-block w-100 carousel"
              src={dforestImg}
              alt="Forest"
              />
            <Carousel.Caption>
             <h3>Dark Forest image</h3>
             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, maiores.</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
              <img 
              className="d-block w-100 carousel"
              src={sunforestImg}
              alt="Forest"
              />
            <Carousel.Caption>
             <h3>Sun Forest image</h3>
             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, maiores.</p>
            </Carousel.Caption>
          </Carousel.Item>
         </Carousel>
        )
    }
}
