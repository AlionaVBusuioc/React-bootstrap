import React, { Component } from 'react';
import './Blog.css';
import CarouselBox from '../Components/CarouselBox';
import {Container, Row, Col, Media, Card, ListGroup} from 'react-bootstrap';

export default class Blog extends Component {
    render() {
        return (
          <Container className="blog">
           <Row>
            <Col md="9">
            <Media className="m-5">
              <img 
              width={150}
              className="mr-3"
              src="https://miro.medium.com/max/720/1*LjR0UrFB2a__5h1DWqzstA.png"
              />
              <Media.Body>
                  <h5>Blog post</h5>
                  <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                      Quam neque illo ea recusandae minus odio minima amet reiciendis,
                      deleniti, explicabo itaque deserunt. Ea quo provident incidunt non ducimus?
                      Incidunt, alias!
                  </p>
              </Media.Body>
            </Media>
            <Media className="m-5">
              <img 
              width={150}
              className="mr-3"
              src="https://miro.medium.com/max/720/1*LjR0UrFB2a__5h1DWqzstA.png"
              />
              <Media.Body>
                  <h5>Blog post</h5>
                  <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                      Quam neque illo ea recusandae minus odio minima amet reiciendis,
                      deleniti, explicabo itaque deserunt. Ea quo provident incidunt non ducimus?
                      Incidunt, alias!
                  </p>
              </Media.Body>
            </Media>
            <Media className="m-5">
              <img 
              width={150}
              className="mr-3"
              src="https://miro.medium.com/max/720/1*LjR0UrFB2a__5h1DWqzstA.png"
              />
              <Media.Body>
                  <h5>Blog post</h5>
                  <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                      Quam neque illo ea recusandae minus odio minima amet reiciendis,
                      deleniti, explicabo itaque deserunt. Ea quo provident incidunt non ducimus?
                      Incidunt, alias!
                  </p>
              </Media.Body>
            </Media>
            <Media className="m-5">
              <img 
              width={150}
              className="mr-3"
              src="https://miro.medium.com/max/720/1*LjR0UrFB2a__5h1DWqzstA.png"
              />
              <Media.Body>
                  <h5>Blog post</h5>
                  <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                      Quam neque illo ea recusandae minus odio minima amet reiciendis,
                      deleniti, explicabo itaque deserunt. Ea quo provident incidunt non ducimus?
                      Incidunt, alias!
                  </p>
              </Media.Body>
            </Media>
            </Col>
            <Col md="3">
            <h5 className="text-center mt-5">Categories</h5>
            <Card>
              <ListGroup variant="flush">
                <ListGroup.Item>Html/Css</ListGroup.Item>
                <ListGroup.Item>Javascript</ListGroup.Item>
                <ListGroup.Item>Pyton</ListGroup.Item>
                <ListGroup.Item>Java</ListGroup.Item>
                <ListGroup.Item>C++</ListGroup.Item>
              </ListGroup>
            </Card>
            <Card className="mt-3" bg="light">
              <Card.Body>
                <Card.Title>Site widget</Card.Title>
                <Card.Text>
                Quam neque illo ea recusandae minus odio minima amet reiciendis,
                deleniti, explicabo itaque deserunt. Ea quo provident incidunt non ducimus?
                Incidunt, alias!
                </Card.Text>
              </Card.Body>
            </Card>
            </Col>
           </Row>
          </Container>
        )
    }
}
