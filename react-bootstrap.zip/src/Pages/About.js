import React, { Component } from 'react';
import './About.css';
import {Container, Tab, Nav, Col, Row } from 'react-bootstrap';

export default class About extends Component {
    render() {
        return (
           <Container className="about">
            <Tab.Container id="left-tabs-example" defaultActiveKey="first">
              <Row>
                  {/* Col -> trebuie sa fie 12 - asa ca impartim cum vrem */}
                  <Col sm={3}>
                  {/* mt-2 (margin top) */}
                    <Nav variant="pills" className="flex-column mt-2">
                      <Nav.Item>
                          <Nav.Link eventKey="first">Design</Nav.Link>
                      </Nav.Item>
                      <Nav.Item>
                          <Nav.Link eventKey="second">Team</Nav.Link>
                      </Nav.Item>
                      <Nav.Item>
                          <Nav.Link eventKey="third">Programming</Nav.Link>
                      </Nav.Item>
                      <Nav.Item>
                          <Nav.Link eventKey="fourth">Frameworks</Nav.Link>
                      </Nav.Item>
                      <Nav.Item>
                          <Nav.Link eventKey="fifth">Libraries</Nav.Link>
                      </Nav.Item>
                    </Nav>
                  </Col>
                  <Col sm={9}>
                  <Tab.Content className="mt-2">
                      <Tab.Pane eventKey="first">
                       <img className="image"
                       src="https://i.ytimg.com/vi/Kf1gILChfks/maxresdefault.jpg"/>
                       <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Aut vel eveniet placeat maiores quae sed velit ratione rem, in iusto.
                            Dolor animi veritatis sed velit?</p>
                      </Tab.Pane>
                      <Tab.Pane eventKey="second">
                       <img className="image"
                       src="https://previews.123rf.com/images/scyther5/scyther51801/scyther5180100085/92925379-business-people-happy-showing-team-work-and-giving-five-in-office-teamwork-concepts-.jpg"/>
                       <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Aut vel eveniet placeat maiores quae sed velit ratione rem, in iusto.
                            Dolor animi veritatis sed velit?</p>
                      </Tab.Pane>
                      <Tab.Pane eventKey="third">
                       <img className="image"
                       src="https://images.unsplash.com/photo-1497215842964-222b430dc094?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80"/>
                       <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Aut vel eveniet placeat maiores quae sed velit ratione rem, in iusto.
                            Dolor animi veritatis sed velit?</p>
                      </Tab.Pane>
                      <Tab.Pane eventKey="fourth">
                       <img className="image"
                       src="https://miro.medium.com/max/8556/1*EM48X61Wygrlqq1BR0kU6Q.png"/>
                       <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Aut vel eveniet placeat maiores quae sed velit ratione rem, in iusto.
                            Dolor animi veritatis sed velit?</p>
                      </Tab.Pane>
                      <Tab.Pane eventKey="fifth">
                       <img className="image"
                       src="https://coderseye.com/wp-content/uploads/Common-Coding-Languages.jpg"/>
                       <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                           Aut vel eveniet placeat maiores quae sed velit ratione rem, in iusto.
                            Dolor animi veritatis sed velit?</p>
                      </Tab.Pane>
                  </Tab.Content>
                  </Col>
              </Row>
            </Tab.Container>
           </Container>
        )   
    }
}
